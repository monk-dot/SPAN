#!/sbin/sh
# Extract the boot.img
dd if=/dev/block/mmcblk0 of=/tmp/boot.img bs=4096 skip=3968 count=2048

#unpack the boot.img
/tmp/unpackbootimg -i /tmp/boot.img -o /tmp/


