#!/sbin/sh
dd if=/tmp/newboot.img of=/dev/block/mmcblk0 seek=3968 bs=4096 count=2048

